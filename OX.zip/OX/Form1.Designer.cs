﻿namespace OX
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.p1 = new System.Windows.Forms.Button();
            this.p2 = new System.Windows.Forms.Button();
            this.p3 = new System.Windows.Forms.Button();
            this.p4 = new System.Windows.Forms.Button();
            this.p5 = new System.Windows.Forms.Button();
            this.p6 = new System.Windows.Forms.Button();
            this.p7 = new System.Windows.Forms.Button();
            this.p8 = new System.Windows.Forms.Button();
            this.p9 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::OX.Properties.Resources.nowagra2;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("AR DESTINE", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.button1.Location = new System.Drawing.Point(13, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(211, 70);
            this.button1.TabIndex = 0;
            this.button1.Text = "NOWA GRA";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // p1
            // 
            this.p1.BackColor = System.Drawing.Color.Transparent;
            this.p1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p1.Enabled = false;
            this.p1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p1.Location = new System.Drawing.Point(12, 164);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(68, 64);
            this.p1.TabIndex = 1;
            this.p1.Text = "1";
            this.p1.UseVisualStyleBackColor = false;
            this.p1.Click += new System.EventHandler(this.p1_Click);
            // 
            // p2
            // 
            this.p2.BackColor = System.Drawing.Color.Transparent;
            this.p2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p2.Enabled = false;
            this.p2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p2.Location = new System.Drawing.Point(86, 164);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(66, 64);
            this.p2.TabIndex = 2;
            this.p2.Text = "2";
            this.p2.UseVisualStyleBackColor = false;
            this.p2.Click += new System.EventHandler(this.p2_Click);
            // 
            // p3
            // 
            this.p3.BackColor = System.Drawing.Color.Transparent;
            this.p3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p3.Enabled = false;
            this.p3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p3.Location = new System.Drawing.Point(158, 164);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(66, 64);
            this.p3.TabIndex = 3;
            this.p3.Text = "3";
            this.p3.UseVisualStyleBackColor = false;
            this.p3.Click += new System.EventHandler(this.p3_Click);
            // 
            // p4
            // 
            this.p4.BackColor = System.Drawing.Color.Transparent;
            this.p4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p4.Enabled = false;
            this.p4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p4.Location = new System.Drawing.Point(12, 240);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(68, 61);
            this.p4.TabIndex = 4;
            this.p4.Text = "4";
            this.p4.UseVisualStyleBackColor = false;
            this.p4.Click += new System.EventHandler(this.p4_Click);
            // 
            // p5
            // 
            this.p5.BackColor = System.Drawing.Color.Transparent;
            this.p5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p5.Enabled = false;
            this.p5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p5.Location = new System.Drawing.Point(86, 240);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(66, 61);
            this.p5.TabIndex = 5;
            this.p5.Text = "5";
            this.p5.UseVisualStyleBackColor = false;
            this.p5.Click += new System.EventHandler(this.p5_Click);
            // 
            // p6
            // 
            this.p6.BackColor = System.Drawing.Color.Transparent;
            this.p6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p6.Enabled = false;
            this.p6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p6.Location = new System.Drawing.Point(158, 240);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(66, 61);
            this.p6.TabIndex = 6;
            this.p6.Text = "6";
            this.p6.UseVisualStyleBackColor = false;
            this.p6.Click += new System.EventHandler(this.p6_Click);
            // 
            // p7
            // 
            this.p7.BackColor = System.Drawing.Color.Transparent;
            this.p7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p7.Enabled = false;
            this.p7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p7.Location = new System.Drawing.Point(13, 315);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(67, 65);
            this.p7.TabIndex = 7;
            this.p7.Text = "7";
            this.p7.UseVisualStyleBackColor = false;
            this.p7.Click += new System.EventHandler(this.p7_Click);
            // 
            // p8
            // 
            this.p8.BackColor = System.Drawing.Color.Transparent;
            this.p8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p8.Enabled = false;
            this.p8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p8.Location = new System.Drawing.Point(86, 315);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(66, 65);
            this.p8.TabIndex = 8;
            this.p8.Text = "8";
            this.p8.UseVisualStyleBackColor = false;
            this.p8.Click += new System.EventHandler(this.p8_Click);
            // 
            // p9
            // 
            this.p9.BackColor = System.Drawing.Color.Transparent;
            this.p9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p9.Enabled = false;
            this.p9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.p9.Location = new System.Drawing.Point(158, 315);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(66, 65);
            this.p9.TabIndex = 9;
            this.p9.Text = "9";
            this.p9.UseVisualStyleBackColor = false;
            this.p9.Click += new System.EventHandler(this.p9_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("AR DESTINE", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(212, 37);
            this.label1.TabIndex = 10;
            this.label1.Text = "Witaj w grze OX  :)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BackgroundImage = global::OX.Properties.Resources.tlo3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(236, 392);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.p9);
            this.Controls.Add(this.p8);
            this.Controls.Add(this.p7);
            this.Controls.Add(this.p6);
            this.Controls.Add(this.p5);
            this.Controls.Add(this.p4);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximumSize = new System.Drawing.Size(252, 431);
            this.MinimumSize = new System.Drawing.Size(252, 431);
            this.Name = "Form1";
            this.Text = "Gra";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button p1;
        private System.Windows.Forms.Button p2;
        private System.Windows.Forms.Button p3;
        private System.Windows.Forms.Button p4;
        private System.Windows.Forms.Button p5;
        private System.Windows.Forms.Button p6;
        private System.Windows.Forms.Button p7;
        private System.Windows.Forms.Button p8;
        private System.Windows.Forms.Button p9;
        private System.Windows.Forms.Label label1;
    }
}

